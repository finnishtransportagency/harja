<b>Nykyinen versio: 0.0.2</b>
<b>Julkaistu: 10.6.2015</b>

<b>Versiohistoria:</b>
- Versionumero: 0.0.4. Julkaistu: 14.7.2015. Muutokset:
    - Toteumien materiaalien ja tehtävien määrää muutettu vastaamaan nykyistä tietomallia
- Versionumero: 0.0.3. Julkaistu: 8.7.2015. Muutokset:
    - Tiestö-, soratie- ja talvihoitotarkastusten payloadit yksinkertaistettu
- Versionumero: 0.0.2. Julkaistu: 10.6.2015. Muutokset:
    - Poistettu päivystäjätietojen haku
    - Lisätty tielupien haku
    - Lisätty tietyö ilmoituksen kirjaus
- Versionumero: 0.0.1. Julkaistu: 9.6.2015. Muutokset:
    - Ensimmäinen versio julkaistu