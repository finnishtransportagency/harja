Harja -järjestelmän julkinen API

API on jaettu kuuteen pääosioon:
<ol>
  <li>urakat:
    <ul>
      <li>Urakoiden perustietojen haku joko urakoitsijan id:llä tai yksittäisen urakan id:llä</li>
      <li>Urakan seurantatietojen kirjaus: toteumat, tarkastukset, turvallisuuspoikkeamat, päivystäjätiedot, laatupoikkeamat sekä tietyöilmoitukset</li>
      <li>Urakan Tieliikennekeskuksen tekemien ilmoitusten haku</li>
    </ul>
  </li>
  <li>seuranta:
      <ul>
        <li>Reaaliaikaisten seurantatietojen, kuten esim. aura-auton liikkeiden kirjaus</li>
      </ul>
    </li>
  <li>ilmoitukset: 
    <ul>
      <li>Tieliikennekeskuksen urakalle tekemien ilmoitusten haku</li>
      <li>Kuittausten eli toimenpiteiden tekeminen ilmoituksille</li>
    </ul>   
  </li>
  <li>tieluvat:
      <ul>
        <li>Tielupien haku</li>
      </ul>
  </li>
  <li>päivystäjätiedot:
        <ul>
          <li>Päivystäjätietojen haku</li>
        </ul>
    </li>
</ol>
